from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime, timedelta
from jose import JWTError, jwt
from passlib.context import CryptContext
import uuid

# ─── Config ───────────────────────────────────────────────
SECRET_KEY = "aqua-sentinel-secret-key-for-food-app"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24

app = FastAPI(title="FoodDash API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login", auto_error=False)

# ─── In-Memory DB ─────────────────────────────────────────
users_db: dict = {}
orders_db: dict = {}
carts_db: dict = {}

# ─── Seed Data ────────────────────────────────────────────
RESTAURANTS = [
    {
        "id": "r1",
        "name": "Spice Garden",
        "cuisine": "North Indian",
        "rating": 4.5,
        "delivery_time": "25-35 min",
        "min_order": 149,
        "image": "🍛",
        "tags": ["Bestseller", "Pure Veg"],
        "menu": [
            {"id": "m1", "name": "Butter Chicken", "price": 280, "description": "Creamy tomato-based curry", "category": "Main Course", "veg": False, "popular": True},
            {"id": "m2", "name": "Dal Makhani", "price": 220, "description": "Slow-cooked black lentils", "category": "Main Course", "veg": True, "popular": True},
            {"id": "m3", "name": "Garlic Naan", "price": 60, "description": "Fresh baked with garlic butter", "category": "Breads", "veg": True, "popular": False},
            {"id": "m4", "name": "Paneer Tikka", "price": 260, "description": "Grilled cottage cheese skewers", "category": "Starters", "veg": True, "popular": True},
            {"id": "m5", "name": "Chicken Biryani", "price": 320, "description": "Fragrant basmati with spiced chicken", "category": "Rice", "veg": False, "popular": True},
            {"id": "m6", "name": "Gulab Jamun", "price": 80, "description": "Soft milk-solid dumplings in syrup", "category": "Desserts", "veg": True, "popular": False},
        ]
    },
    {
        "id": "r2",
        "name": "Dragon Wok",
        "cuisine": "Chinese",
        "rating": 4.2,
        "delivery_time": "20-30 min",
        "min_order": 199,
        "image": "🍜",
        "tags": ["Fast Delivery"],
        "menu": [
            {"id": "m7", "name": "Veg Fried Rice", "price": 180, "description": "Wok-tossed with fresh vegetables", "category": "Rice", "veg": True, "popular": True},
            {"id": "m8", "name": "Chicken Manchurian", "price": 240, "description": "Crispy chicken in tangy sauce", "category": "Main Course", "veg": False, "popular": True},
            {"id": "m9", "name": "Spring Rolls", "price": 150, "description": "Crispy stuffed rolls with dip", "category": "Starters", "veg": True, "popular": False},
            {"id": "m10", "name": "Hakka Noodles", "price": 190, "description": "Stir-fried noodles with veggies", "category": "Noodles", "veg": True, "popular": True},
            {"id": "m11", "name": "Kung Pao Chicken", "price": 280, "description": "Spicy stir-fry with peanuts", "category": "Main Course", "veg": False, "popular": False},
            {"id": "m12", "name": "Honey Chilli Potato", "price": 160, "description": "Crispy potatoes in sweet-spicy glaze", "category": "Starters", "veg": True, "popular": True},
        ]
    },
    {
        "id": "r3",
        "name": "Pizza Parlour",
        "cuisine": "Italian",
        "rating": 4.6,
        "delivery_time": "30-45 min",
        "min_order": 299,
        "image": "🍕",
        "tags": ["Trending", "Premium"],
        "menu": [
            {"id": "m13", "name": "Margherita Pizza", "price": 299, "description": "Classic tomato base with mozzarella", "category": "Pizza", "veg": True, "popular": True},
            {"id": "m14", "name": "BBQ Chicken Pizza", "price": 399, "description": "Smoky BBQ with grilled chicken", "category": "Pizza", "veg": False, "popular": True},
            {"id": "m15", "name": "Pasta Arrabbiata", "price": 249, "description": "Penne in spicy tomato sauce", "category": "Pasta", "veg": True, "popular": False},
            {"id": "m16", "name": "Garlic Bread", "price": 149, "description": "Toasted with herb butter", "category": "Sides", "veg": True, "popular": True},
            {"id": "m17", "name": "Tiramisu", "price": 199, "description": "Classic Italian coffee dessert", "category": "Desserts", "veg": True, "popular": False},
        ]
    },
    {
        "id": "r4",
        "name": "Burger Barn",
        "cuisine": "American",
        "rating": 4.3,
        "delivery_time": "15-25 min",
        "min_order": 149,
        "image": "🍔",
        "tags": ["Fast Delivery", "Value"],
        "menu": [
            {"id": "m18", "name": "Classic Smash Burger", "price": 249, "description": "Double patty with special sauce", "category": "Burgers", "veg": False, "popular": True},
            {"id": "m19", "name": "Crispy Chicken Burger", "price": 229, "description": "Fried chicken fillet with coleslaw", "category": "Burgers", "veg": False, "popular": True},
            {"id": "m20", "name": "Veg Patty Burger", "price": 179, "description": "Aloo-tikki patty, tangy sauces", "category": "Burgers", "veg": True, "popular": False},
            {"id": "m21", "name": "Loaded Fries", "price": 149, "description": "Cheese, jalapeños, sour cream", "category": "Sides", "veg": True, "popular": True},
            {"id": "m22", "name": "Chocolate Milkshake", "price": 129, "description": "Thick creamy chocolate shake", "category": "Drinks", "veg": True, "popular": False},
        ]
    },
    {
        "id": "r5",
        "name": "South Spice",
        "cuisine": "South Indian",
        "rating": 4.7,
        "delivery_time": "20-30 min",
        "min_order": 99,
        "image": "🥘",
        "tags": ["Bestseller", "Healthy"],
        "menu": [
            {"id": "m23", "name": "Masala Dosa", "price": 120, "description": "Crispy crepe with spiced potato filling", "category": "Breakfast", "veg": True, "popular": True},
            {"id": "m24", "name": "Idli Sambar", "price": 90, "description": "Steamed rice cakes with lentil soup", "category": "Breakfast", "veg": True, "popular": True},
            {"id": "m25", "name": "Chettinad Chicken Curry", "price": 280, "description": "Bold spiced chicken in aromatic gravy", "category": "Main Course", "veg": False, "popular": True},
            {"id": "m26", "name": "Medu Vada", "price": 80, "description": "Crispy lentil donuts with chutney", "category": "Starters", "veg": True, "popular": False},
            {"id": "m27", "name": "Filter Coffee", "price": 60, "description": "Traditional South Indian decoction", "category": "Drinks", "veg": True, "popular": True},
        ]
    },
]

# ─── Models ───────────────────────────────────────────────
class UserRegister(BaseModel):
    name: str
    email: str
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str
    user: dict

class CartItem(BaseModel):
    restaurant_id: str
    item_id: str
    quantity: int

class OrderCreate(BaseModel):
    restaurant_id: str
    items: List[dict]
    address: str
    payment_method: str = "COD"

# ─── Auth Helpers ─────────────────────────────────────────
def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)

def create_token(data: dict) -> str:
    to_encode = data.copy()
    to_encode["exp"] = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def get_current_user(token: str = Depends(oauth2_scheme)):
    if not token:
        return None
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email = payload.get("sub")
        return users_db.get(email)
    except JWTError:
        return None

# ─── Auth Routes ──────────────────────────────────────────
@app.post("/auth/register", response_model=Token)
def register(data: UserRegister):
    if data.email in users_db:
        raise HTTPException(400, "Email already registered")
    user = {"id": str(uuid.uuid4()), "name": data.name, "email": data.email,
            "password": hash_password(data.password), "created_at": datetime.utcnow().isoformat()}
    users_db[data.email] = user
    token = create_token({"sub": data.email})
    return {"access_token": token, "token_type": "bearer",
            "user": {"id": user["id"], "name": user["name"], "email": user["email"]}}

@app.post("/auth/login", response_model=Token)
def login(form: OAuth2PasswordRequestForm = Depends()):
    user = users_db.get(form.username)
    if not user or not verify_password(form.password, user["password"]):
        raise HTTPException(401, "Invalid credentials")
    token = create_token({"sub": form.username})
    return {"access_token": token, "token_type": "bearer",
            "user": {"id": user["id"], "name": user["name"], "email": user["email"]}}

@app.get("/auth/me")
def me(user=Depends(get_current_user)):
    if not user:
        raise HTTPException(401, "Not authenticated")
    return {"id": user["id"], "name": user["name"], "email": user["email"]}

# ─── Restaurant Routes ────────────────────────────────────
@app.get("/restaurants")
def get_restaurants(cuisine: Optional[str] = None, search: Optional[str] = None):
    results = RESTAURANTS
    if cuisine:
        results = [r for r in results if r["cuisine"].lower() == cuisine.lower()]
    if search:
        q = search.lower()
        results = [r for r in results if q in r["name"].lower() or q in r["cuisine"].lower()]
    return [{"id": r["id"], "name": r["name"], "cuisine": r["cuisine"],
             "rating": r["rating"], "delivery_time": r["delivery_time"],
             "min_order": r["min_order"], "image": r["image"], "tags": r["tags"]} for r in results]

@app.get("/restaurants/{restaurant_id}")
def get_restaurant(restaurant_id: str):
    r = next((r for r in RESTAURANTS if r["id"] == restaurant_id), None)
    if not r:
        raise HTTPException(404, "Restaurant not found")
    return r

@app.get("/restaurants/{restaurant_id}/menu")
def get_menu(restaurant_id: str):
    r = next((r for r in RESTAURANTS if r["id"] == restaurant_id), None)
    if not r:
        raise HTTPException(404, "Restaurant not found")
    return r["menu"]

# ─── Cart Routes ──────────────────────────────────────────
@app.get("/cart")
def get_cart(user=Depends(get_current_user)):
    if not user:
        return {"items": [], "total": 0}
    cart = carts_db.get(user["id"], {"restaurant_id": None, "items": {}})
    return _build_cart_response(cart)

@app.post("/cart/add")
def add_to_cart(item: CartItem, user=Depends(get_current_user)):
    if not user:
        raise HTTPException(401, "Login required")
    cart = carts_db.get(user["id"], {"restaurant_id": None, "items": {}})
    if cart["restaurant_id"] and cart["restaurant_id"] != item.restaurant_id:
        cart = {"restaurant_id": None, "items": {}}  # reset if different restaurant
    cart["restaurant_id"] = item.restaurant_id
    cart["items"][item.item_id] = cart["items"].get(item.item_id, 0) + item.quantity
    if cart["items"][item.item_id] <= 0:
        del cart["items"][item.item_id]
    carts_db[user["id"]] = cart
    return _build_cart_response(cart)

@app.delete("/cart/clear")
def clear_cart(user=Depends(get_current_user)):
    if not user:
        raise HTTPException(401, "Login required")
    carts_db[user["id"]] = {"restaurant_id": None, "items": {}}
    return {"message": "Cart cleared"}

def _build_cart_response(cart):
    if not cart["restaurant_id"] or not cart["items"]:
        return {"restaurant_id": None, "items": [], "total": 0, "item_count": 0}
    restaurant = next((r for r in RESTAURANTS if r["id"] == cart["restaurant_id"]), None)
    enriched = []
    total = 0
    for item_id, qty in cart["items"].items():
        menu_item = next((m for m in restaurant["menu"] if m["id"] == item_id), None)
        if menu_item:
            subtotal = menu_item["price"] * qty
            total += subtotal
            enriched.append({**menu_item, "quantity": qty, "subtotal": subtotal})
    return {"restaurant_id": cart["restaurant_id"], "restaurant_name": restaurant["name"],
            "items": enriched, "total": total, "item_count": sum(cart["items"].values())}

# ─── Order Routes ─────────────────────────────────────────
@app.post("/orders")
def place_order(order: OrderCreate, user=Depends(get_current_user)):
    if not user:
        raise HTTPException(401, "Login required")
    total = sum(i["price"] * i["quantity"] for i in order.items)
    new_order = {
        "id": str(uuid.uuid4())[:8].upper(),
        "user_id": user["id"],
        "restaurant_id": order.restaurant_id,
        "restaurant_name": next((r["name"] for r in RESTAURANTS if r["id"] == order.restaurant_id), ""),
        "items": order.items,
        "total": total,
        "address": order.address,
        "payment_method": order.payment_method,
        "status": "confirmed",
        "placed_at": datetime.utcnow().isoformat(),
        "estimated_delivery": "30-45 min",
    }
    if user["id"] not in orders_db:
        orders_db[user["id"]] = []
    orders_db[user["id"]].append(new_order)
    carts_db[user["id"]] = {"restaurant_id": None, "items": {}}
    return new_order

@app.get("/orders")
def get_orders(user=Depends(get_current_user)):
    if not user:
        raise HTTPException(401, "Login required")
    return orders_db.get(user["id"], [])

@app.get("/orders/{order_id}")
def get_order(order_id: str, user=Depends(get_current_user)):
    if not user:
        raise HTTPException(401, "Login required")
    user_orders = orders_db.get(user["id"], [])
    order = next((o for o in user_orders if o["id"] == order_id), None)
    if not order:
        raise HTTPException(404, "Order not found")
    return order

@app.get("/")
def root():
    return {"message": "FoodDash API running", "version": "1.0.0", "docs": "/docs"}
