'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth, useCart } from '@/context/providers';
import { api } from '@/lib/api';

export default function CartPage() {
  const { user } = useAuth();
  const { cart, addItem, clearCart } = useCart();
  const router = useRouter();
  const [address, setAddress] = useState('');
  const [payment, setPayment] = useState('COD');
  const [placing, setPlacing] = useState(false);
  const [error, setError] = useState('');

  const deliveryFee = cart.total > 0 ? 40 : 0;
  const taxes = Math.round(cart.total * 0.05);
  const grandTotal = cart.total + deliveryFee + taxes;

  const placeOrder = async () => {
    if (!address.trim()) { setError('Please enter a delivery address'); return; }
    setError(''); setPlacing(true);
    try {
      const order = await api.placeOrder({
        restaurant_id: cart.restaurant_id!,
        items: cart.items.map((i: any) => ({ id: i.id, name: i.name, price: i.price, quantity: i.quantity })),
        address, payment_method: payment,
      });
      router.push(`/orders?new=${order.id}`);
    } catch (e: any) { setError(e.message); setPlacing(false); }
  };

  if (!user) return (
    <div style={{ maxWidth: 600, margin: '80px auto', textAlign: 'center', padding: '0 24px' }}>
      <p style={{ fontSize: 48, marginBottom: 16 }}>🔒</p>
      <h2 style={{ fontFamily: 'Syne', fontSize: 24, marginBottom: 12 }}>Log in to view your cart</h2>
      <p style={{ color: 'var(--muted)', marginBottom: 28 }}>Create an account or sign in to continue</p>
      <Link href="/"><button className="btn-primary" style={{ borderRadius: 12, padding: '12px 32px', fontSize: 16 }}>Go Home</button></Link>
    </div>
  );

  if (cart.items.length === 0) return (
    <div style={{ maxWidth: 600, margin: '80px auto', textAlign: 'center', padding: '0 24px' }}>
      <p style={{ fontSize: 64, marginBottom: 16 }}>🛒</p>
      <h2 style={{ fontFamily: 'Syne', fontSize: 26, marginBottom: 12 }}>Your cart is empty</h2>
      <p style={{ color: 'var(--muted)', marginBottom: 28 }}>Add items from a restaurant to get started</p>
      <Link href="/"><button className="btn-primary" style={{ borderRadius: 12, padding: '12px 32px', fontSize: 16 }}>Browse Restaurants</button></Link>
    </div>
  );

  return (
    <div style={{ maxWidth: 900, margin: '0 auto', padding: '40px 24px' }}>
      <h1 style={{ fontFamily: 'Syne', fontSize: 32, fontWeight: 800, marginBottom: 8 }}>Your Cart</h1>
      <p style={{ color: 'var(--muted)', marginBottom: 32 }}>from {cart.restaurant_name}</p>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 28, alignItems: 'start' }}>
        {/* Items */}
        <div>
          <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 16, overflow: 'hidden', marginBottom: 20 }}>
            {cart.items.map((item: any, i: number) => (
              <div key={item.id} style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                padding: '16px 20px',
                borderBottom: i < cart.items.length - 1 ? '1px solid var(--border)' : 'none',
              }}>
                <div>
                  <p style={{ fontFamily: 'Syne', fontWeight: 600, marginBottom: 4 }}>{item.name}</p>
                  <p style={{ color: 'var(--muted)', fontSize: 13 }}>₹{item.price} × {item.quantity}</p>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'var(--surface2)', borderRadius: 8, padding: '5px 10px' }}>
                    <button onClick={() => addItem(cart.restaurant_id!, item.id, -1)} style={{
                      width: 24, height: 24, borderRadius: '50%', background: 'var(--accent)',
                      border: 'none', color: 'white', fontWeight: 700, cursor: 'pointer',
                    }}>−</button>
                    <span style={{ fontFamily: 'Syne', fontWeight: 700 }}>{item.quantity}</span>
                    <button onClick={() => addItem(cart.restaurant_id!, item.id, 1)} style={{
                      width: 24, height: 24, borderRadius: '50%', background: 'var(--accent)',
                      border: 'none', color: 'white', fontWeight: 700, cursor: 'pointer',
                    }}>+</button>
                  </div>
                  <span style={{ fontFamily: 'Syne', fontWeight: 700, minWidth: 70, textAlign: 'right' }}>₹{item.subtotal}</span>
                </div>
              </div>
            ))}
          </div>
          <button onClick={clearCart} style={{
            background: 'transparent', border: '1px solid var(--red)', color: 'var(--red)',
            borderRadius: 10, padding: '8px 18px', cursor: 'pointer', fontFamily: 'Syne', fontSize: 13,
          }}>🗑 Clear cart</button>
        </div>

        {/* Summary + Checkout */}
        <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 24 }}>
          <h3 style={{ fontFamily: 'Syne', fontSize: 18, marginBottom: 20 }}>Order Summary</h3>

          {[['Subtotal', `₹${cart.total}`], ['Delivery fee', `₹${deliveryFee}`], ['Taxes (5%)', `₹${taxes}`]].map(([k, v]) => (
            <div key={k} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10, fontSize: 14, color: 'var(--muted)' }}>
              <span>{k}</span><span>{v}</span>
            </div>
          ))}
          <div style={{ borderTop: '1px solid var(--border)', margin: '16px 0', paddingTop: 16, display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: 17 }}>Total</span>
            <span style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: 17, color: 'var(--accent)' }}>₹{grandTotal}</span>
          </div>

          <div style={{ marginBottom: 16 }}>
            <label style={{ fontSize: 13, color: 'var(--muted)', display: 'block', marginBottom: 6, fontFamily: 'Syne' }}>Delivery Address</label>
            <textarea placeholder="Enter your full address…" value={address} onChange={e => setAddress(e.target.value)}
              rows={3} style={{ resize: 'none' }} />
          </div>

          <div style={{ marginBottom: 20 }}>
            <label style={{ fontSize: 13, color: 'var(--muted)', display: 'block', marginBottom: 6, fontFamily: 'Syne' }}>Payment Method</label>
            <div style={{ display: 'flex', gap: 10 }}>
              {['COD', 'UPI', 'Card'].map(p => (
                <button key={p} onClick={() => setPayment(p)} style={{
                  flex: 1, padding: '9px', borderRadius: 9, border: '1px solid',
                  borderColor: payment === p ? 'var(--accent)' : 'var(--border)',
                  background: payment === p ? 'rgba(255,107,53,0.15)' : 'var(--surface2)',
                  color: payment === p ? 'var(--accent)' : 'var(--muted)',
                  cursor: 'pointer', fontFamily: 'Syne', fontWeight: 600, fontSize: 13, transition: 'all 0.2s',
                }}>{p}</button>
              ))}
            </div>
          </div>

          {error && <p style={{ color: 'var(--red)', fontSize: 13, marginBottom: 12 }}>{error}</p>}

          <button onClick={placeOrder} className="btn-primary" disabled={placing} style={{
            width: '100%', padding: '14px', borderRadius: 12, fontSize: 16, opacity: placing ? 0.7 : 1,
          }}>
            {placing ? 'Placing order…' : `Place Order · ₹${grandTotal}`}
          </button>
        </div>
      </div>
    </div>
  );
}
