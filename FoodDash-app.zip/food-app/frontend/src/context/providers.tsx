'use client';
import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { api } from '@/lib/api';

// ─── Auth Context ─────────────────────────────────────────
interface User { id: string; name: string; email: string; }
interface AuthCtx {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthCtx>({} as AuthCtx);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const saved = localStorage.getItem('user');
    if (token && saved) {
      try { setUser(JSON.parse(saved)); } catch {}
    }
  }, []);

  const login = async (email: string, password: string) => {
    const data = await api.login(email, password);
    if (data.access_token) {
      localStorage.setItem('token', data.access_token);
      localStorage.setItem('user', JSON.stringify(data.user));
      setUser(data.user);
    } else throw new Error(data.detail || 'Login failed');
  };

  const register = async (name: string, email: string, password: string) => {
    const data = await api.register(name, email, password);
    if (data.access_token) {
      localStorage.setItem('token', data.access_token);
      localStorage.setItem('user', JSON.stringify(data.user));
      setUser(data.user);
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
  };

  return <AuthContext.Provider value={{ user, login, register, logout }}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);

// ─── Cart Context ─────────────────────────────────────────
interface CartItem { id: string; name: string; price: number; quantity: number; subtotal: number; }
interface Cart { restaurant_id: string | null; restaurant_name?: string; items: CartItem[]; total: number; item_count: number; }
interface CartCtx {
  cart: Cart;
  addItem: (restaurant_id: string, item_id: string, qty?: number) => Promise<void>;
  refreshCart: () => Promise<void>;
  clearCart: () => Promise<void>;
}

const CartContext = createContext<CartCtx>({} as CartCtx);
const emptyCart: Cart = { restaurant_id: null, items: [], total: 0, item_count: 0 };

export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<Cart>(emptyCart);
  const { user } = useAuth();

  const refreshCart = useCallback(async () => {
    if (!user) { setCart(emptyCart); return; }
    try { setCart(await api.getCart()); } catch { setCart(emptyCart); }
  }, [user]);

  useEffect(() => { refreshCart(); }, [refreshCart]);

  const addItem = async (restaurant_id: string, item_id: string, qty = 1) => {
    await api.addToCart(restaurant_id, item_id, qty);
    await refreshCart();
  };

  const clearCart = async () => {
    await api.clearCart();
    setCart(emptyCart);
  };

  return <CartContext.Provider value={{ cart, addItem, refreshCart, clearCart }}>{children}</CartContext.Provider>;
}

export const useCart = () => useContext(CartContext);
