const BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

function getToken(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('token');
}

async function request(path: string, options: RequestInit = {}) {
  const token = getToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> || {}),
  };
  if (token) headers['Authorization'] = `Bearer ${token}`;
  const res = await fetch(`${BASE_URL}${path}`, { ...options, headers });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Request failed' }));
    throw new Error(err.detail || 'Request failed');
  }
  return res.json();
}

export const api = {
  // Auth
  register: (name: string, email: string, password: string) =>
    request('/auth/register', { method: 'POST', body: JSON.stringify({ name, email, password }) }),

  login: (email: string, password: string) => {
    const body = new URLSearchParams({ username: email, password });
    return fetch(`${BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString(),
    }).then(r => r.json());
  },

  me: () => request('/auth/me'),

  // Restaurants
  getRestaurants: (params?: { search?: string; cuisine?: string }) => {
    const q = new URLSearchParams(params as Record<string, string>).toString();
    return request(`/restaurants${q ? '?' + q : ''}`);
  },

  getRestaurant: (id: string) => request(`/restaurants/${id}`),
  getMenu: (id: string) => request(`/restaurants/${id}/menu`),

  // Cart
  getCart: () => request('/cart'),
  addToCart: (restaurant_id: string, item_id: string, quantity: number) =>
    request('/cart/add', { method: 'POST', body: JSON.stringify({ restaurant_id, item_id, quantity }) }),
  clearCart: () => request('/cart/clear', { method: 'DELETE' }),

  // Orders
  placeOrder: (data: { restaurant_id: string; items: object[]; address: string; payment_method: string }) =>
    request('/orders', { method: 'POST', body: JSON.stringify(data) }),
  getOrders: () => request('/orders'),
};
